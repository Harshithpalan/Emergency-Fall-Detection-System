// ============================================================
// Fall Detection Prototype — app.js
// MediaPipe Pose runs fully on-device. No data leaves the browser.
// ============================================================

const video = document.getElementById('video');
const overlay = document.getElementById('overlay');
const overlayCtx = overlay.getContext('2d');
const trailCanvas = document.getElementById('trailCanvas');
const trailCtx = trailCanvas.getContext('2d');

const camPlaceholder = document.getElementById('camPlaceholder');
const startBtn = document.getElementById('startBtn');
const statusPill = document.getElementById('statusPill');
const statusText = document.getElementById('statusText');
const fpsLabel = document.getElementById('fpsLabel');
const alertFlash = document.getElementById('alertFlash');

const metricAngle = document.getElementById('metricAngle');
const metricVel = document.getElementById('metricVel');
const metricPosture = document.getElementById('metricPosture');

const sensSlider = document.getElementById('sensSlider');
const sensVal = document.getElementById('sensVal');
const stillSlider = document.getElementById('stillSlider');
const stillVal = document.getElementById('stillVal');
const soundToggle = document.getElementById('soundToggle');
const recordToggle = document.getElementById('recordToggle');
const simulateBtn = document.getElementById('simulateBtn');
const clearLogBtn = document.getElementById('clearLogBtn');
const logList = document.getElementById('logList');
const logCount = document.getElementById('logCount');

let SENSITIVITY = parseFloat(sensSlider.value);   // velocity threshold
let STILL_WINDOW = parseFloat(stillSlider.value);  // seconds

sensSlider.addEventListener('input', () => {
  SENSITIVITY = parseFloat(sensSlider.value);
  sensVal.textContent = SENSITIVITY.toFixed(2);
});
stillSlider.addEventListener('input', () => {
  STILL_WINDOW = parseFloat(stillSlider.value);
  stillVal.textContent = STILL_WINDOW.toFixed(1);
});
[soundToggle, recordToggle].forEach(sw => {
  sw.addEventListener('click', () => sw.classList.toggle('on'));
});

// ---- state ----
let stream = null;
let pose = null;
let running = false;
let lastFrameTime = performance.now();
let fpsHistory = [];

let hipYHistory = [];        // {t, y} normalized hip-mid y position
const HISTORY_MS = 6000;     // keep 6s of history for the trail
let postFallTimer = null;
let alertActive = false;
let lastAlertTime = 0;
const ALERT_COOLDOWN_MS = 8000;

// rolling buffer for local "clip" capture (canvas frames)
let frameBuffer = [];        // {t, dataUrl}
const CLIP_SECONDS = 6;

let incidentCount = 0;

// ============================================================
// Camera + Pose setup
// ============================================================

async function startCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: 640, height: 480, facingMode: 'user' },
      audio: false
    });
    video.srcObject = stream;
    await video.play();
    camPlaceholder.style.display = 'none';
    setStatus('monitoring', false);
    resizeCanvases();
    initPose();
  } catch (err) {
    statusText.textContent = 'camera blocked';
    camPlaceholder.innerHTML =
      'Could not access camera.<br>Check browser permissions and reload.' +
      '<br><button id="startBtn2" class="retryBtn">Try again</button>';
    document.getElementById('startBtn2')?.addEventListener('click', startCamera);
  }
}

function resizeCanvases() {
  overlay.width = video.videoWidth || 640;
  overlay.height = video.videoHeight || 480;
  trailCanvas.width = trailCanvas.clientWidth * devicePixelRatio;
  trailCanvas.height = trailCanvas.clientHeight * devicePixelRatio;
}
window.addEventListener('resize', resizeCanvases);

function initPose() {
  pose = new Pose({
    locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`
  });
  pose.setOptions({
    modelComplexity: 1,
    smoothLandmarks: true,
    enableSegmentation: false,
    minDetectionConfidence: 0.6,
    minTrackingConfidence: 0.5
  });
  pose.onResults(onPoseResults);
  running = true;
  pumpFrames();
}

async function pumpFrames() {
  if (!running) return;
  if (video.readyState >= 2) {
    await pose.send({ image: video });
  }
  requestAnimationFrame(pumpFrames);
}

// ============================================================
// Pose results → metrics → fall heuristic
// ============================================================

const LM = {
  LSHOULDER: 11, RSHOULDER: 12,
  LHIP: 23, RHIP: 24,
  LKNEE: 25, RKNEE: 26,
  NOSE: 0
};

let prevHipMid = null;
let prevTime = null;
let stillSince = null;
let fallCandidateAt = null;

function onPoseResults(results) {
  const now = performance.now();

  // fps
  const dt = now - lastFrameTime;
  lastFrameTime = now;
  if (dt > 0) {
    fpsHistory.push(1000 / dt);
    if (fpsHistory.length > 20) fpsHistory.shift();
    const avgFps = fpsHistory.reduce((a, b) => a + b, 0) / fpsHistory.length;
    fpsLabel.textContent = `${avgFps.toFixed(0)} fps`;
  }

  drawOverlay(results);
  captureFrameForClip();

  if (!results.poseLandmarks) {
    metricPosture.textContent = 'no person';
    return;
  }

  const lm = results.poseLandmarks;
  const ls = lm[LM.LSHOULDER], rs = lm[LM.RSHOULDER];
  const lh = lm[LM.LHIP], rh = lm[LM.RHIP];

  if (!ls || !rs || !lh || !rh) return;

  const shoulderMid = { x: (ls.x + rs.x) / 2, y: (ls.y + rs.y) / 2 };
  const hipMid = { x: (lh.x + rh.x) / 2, y: (lh.y + rh.y) / 2 };

  // torso angle from vertical (0 = standing upright, 90 = horizontal/fallen)
  const dx = shoulderMid.x - hipMid.x;
  const dy = shoulderMid.y - hipMid.y;
  const angleFromVertical = Math.atan2(Math.abs(dx), Math.abs(dy)) * (180 / Math.PI);

  metricAngle.textContent = `${angleFromVertical.toFixed(0)}°`;

  // vertical velocity of hip midpoint (normalized units/sec)
  let velocity = 0;
  const t = now;
  if (prevHipMid && prevTime) {
    const deltaT = (t - prevTime) / 1000;
    if (deltaT > 0) {
      velocity = (hipMid.y - prevHipMid.y) / deltaT; // positive = moving down
    }
  }
  prevHipMid = hipMid;
  prevTime = t;

  metricVel.textContent = velocity.toFixed(2);

  // record history for trail
  hipYHistory.push({ t, y: hipMid.y, angle: angleFromVertical });
  const cutoff = t - HISTORY_MS;
  hipYHistory = hipYHistory.filter(p => p.t >= cutoff);
  drawTrail();

  // posture classification
  let posture = 'standing';
  if (angleFromVertical > 60) posture = 'horizontal';
  else if (angleFromVertical > 30) posture = 'leaning / sitting';
  metricPosture.textContent = posture;

  // ---- fall heuristic ----
  // 1. sharp downward velocity spike beyond threshold
  // 2. followed by sustained near-horizontal stillness
  evaluateFallHeuristic(velocity, angleFromVertical, t);
}

function evaluateFallHeuristic(velocity, angle, t) {
  const droppedFast = velocity > SENSITIVITY;

  if (droppedFast && !fallCandidateAt) {
    fallCandidateAt = t;
  }

  if (fallCandidateAt) {
    const sinceCandidate = (t - fallCandidateAt) / 1000;
    const isHorizontalNow = angle > 55;
    const isStill = Math.abs(velocity) < 0.06;

    if (isHorizontalNow && isStill) {
      if (!stillSince) stillSince = t;
      const stillFor = (t - stillSince) / 1000;
      if (stillFor >= STILL_WINDOW) {
        triggerFallAlert();
        fallCandidateAt = null;
        stillSince = null;
      }
    } else if (!isHorizontalNow) {
      // recovered without falling — reset
      fallCandidateAt = null;
      stillSince = null;
    }

    // candidate expires if nothing resolves within 4s
    if (sinceCandidate > 4) {
      fallCandidateAt = null;
      stillSince = null;
    }
  }
}

// ============================================================
// Drawing: skeleton overlay + trail
// ============================================================

function drawOverlay(results) {
  overlayCtx.save();
  overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
  if (results.poseLandmarks) {
    drawConnectors(overlayCtx, results.poseLandmarks, POSE_CONNECTIONS,
      { color: alertActive ? '#d64545' : '#3a7d7a', lineWidth: 3 });
    drawLandmarks(overlayCtx, results.poseLandmarks,
      { color: '#e8a23c', radius: 3, lineWidth: 1 });
  }
  overlayCtx.restore();
}

function drawTrail() {
  const w = trailCanvas.width, h = trailCanvas.height;
  trailCtx.clearRect(0, 0, w, h);

  // grid baseline
  trailCtx.strokeStyle = 'rgba(255,255,255,0.06)';
  trailCtx.lineWidth = 1;
  for (let i = 1; i < 4; i++) {
    const y = (h / 4) * i;
    trailCtx.beginPath();
    trailCtx.moveTo(0, y);
    trailCtx.lineTo(w, y);
    trailCtx.stroke();
  }

  if (hipYHistory.length < 2) return;

  const now = performance.now();
  const tMin = now - HISTORY_MS;

  trailCtx.beginPath();
  hipYHistory.forEach((p, i) => {
    const x = ((p.t - tMin) / HISTORY_MS) * w;
    const y = p.y * h; // y already normalized 0-1 (top to bottom)
    if (i === 0) trailCtx.moveTo(x, y);
    else trailCtx.lineTo(x, y);
  });

  // gradient stroke — teal normally, flares red near a spike
  const grad = trailCtx.createLinearGradient(0, 0, w, 0);
  grad.addColorStop(0, '#3a7d7a');
  grad.addColorStop(1, alertActive ? '#d64545' : '#e8a23c');
  trailCtx.strokeStyle = grad;
  trailCtx.lineWidth = 2 * devicePixelRatio;
  trailCtx.lineJoin = 'round';
  trailCtx.stroke();

  // glow dot at latest point
  const last = hipYHistory[hipYHistory.length - 1];
  const lx = ((last.t - tMin) / HISTORY_MS) * w;
  const ly = last.y * h;
  trailCtx.beginPath();
  trailCtx.arc(lx, ly, 4 * devicePixelRatio, 0, Math.PI * 2);
  trailCtx.fillStyle = alertActive ? '#d64545' : '#e8a23c';
  trailCtx.shadowColor = trailCtx.fillStyle;
  trailCtx.shadowBlur = 10;
  trailCtx.fill();
  trailCtx.shadowBlur = 0;
}

// ============================================================
// Local clip buffer (rolling, in-memory only)
// ============================================================

let clipCanvas = document.createElement('canvas');
let clipCtx = clipCanvas.getContext('2d');

function captureFrameForClip() {
  if (!recordToggle.classList.contains('on')) return;
  if (!video.videoWidth) return;

  clipCanvas.width = 320;
  clipCanvas.height = 240;
  clipCtx.save();
  clipCtx.scale(-1, 1);
  clipCtx.drawImage(video, -320, 0, 320, 240);
  clipCtx.restore();

  const t = performance.now();
  frameBuffer.push({ t, dataUrl: clipCanvas.toDataURL('image/jpeg', 0.5) });

  const cutoff = t - CLIP_SECONDS * 1000;
  frameBuffer = frameBuffer.filter(f => f.t >= cutoff);
}

function buildClipPreviewFrames() {
  // returns a handful of evenly-spaced frames from the buffer for a lightweight "scrub strip"
  if (frameBuffer.length === 0) return [];
  const samples = 5;
  const step = Math.max(1, Math.floor(frameBuffer.length / samples));
  const out = [];
  for (let i = 0; i < frameBuffer.length; i += step) out.push(frameBuffer[i]);
  return out.slice(-samples);
}

// ============================================================
// Alerts + incident log
// ============================================================

function setStatus(mode, isAlert) {
  if (isAlert) {
    statusPill.classList.add('alert');
    statusText.textContent = 'fall detected';
  } else {
    statusPill.classList.remove('alert');
    statusText.textContent = mode === 'monitoring' ? 'monitoring' : 'camera off';
  }
}

function triggerFallAlert() {
  const now = performance.now();
  if (now - lastAlertTime < ALERT_COOLDOWN_MS) return;
  lastAlertTime = now;

  alertActive = true;
  setStatus('monitoring', true);
  flashScreen();
  if (soundToggle.classList.contains('on')) playAlarm();
  logIncident();

  setTimeout(() => {
    alertActive = false;
    setStatus('monitoring', false);
  }, 4000);
}

function flashScreen() {
  alertFlash.classList.add('show');
  setTimeout(() => alertFlash.classList.remove('show'), 1600);
}

// Simple synthesized alarm tone (no external audio file needed)
let audioCtx = null;
function playAlarm() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const now = audioCtx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(880, now + i * 0.35);
      osc.frequency.setValueAtTime(660, now + i * 0.35 + 0.15);
      gain.gain.setValueAtTime(0.0001, now + i * 0.35);
      gain.gain.exponentialRampToValueAtTime(0.18, now + i * 0.35 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.35 + 0.3);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(now + i * 0.35);
      osc.stop(now + i * 0.35 + 0.32);
    }
  } catch (e) { /* audio not available, ignore */ }
}

function logIncident() {
  incidentCount++;
  logCount.textContent = `${incidentCount} event${incidentCount === 1 ? '' : 's'}`;

  const emptyEl = logList.querySelector('.log-empty');
  if (emptyEl) emptyEl.remove();

  const ts = new Date();
  const item = document.createElement('div');
  item.className = 'log-item';

  let clipHtml = '';
  if (recordToggle.classList.contains('on')) {
    const frames = buildClipPreviewFrames();
    if (frames.length) {
      clipHtml = `<div style="display:flex;gap:4px;margin-top:8px;">` +
        frames.map(f => `<img src="${f.dataUrl}" style="width:${100/frames.length}%;border-radius:4px;border:1px solid #2a313b;transform:scaleX(-1);">`).join('') +
        `</div><div style="font-size:10px;color:#666b75;margin-top:5px;">local-only clip · ${frames.length} frames · not uploaded anywhere</div>`;
    }
  }

  item.innerHTML = `
    <span class="tag">FALL DETECTED</span>
    <div class="lt"><b>${ts.toLocaleTimeString()}</b><span>${ts.toLocaleDateString()}</span></div>
    <div class="desc">Vertical drop exceeded sensitivity threshold (${SENSITIVITY.toFixed(2)}), followed by ${STILL_WINDOW.toFixed(1)}s of near-horizontal stillness.</div>
    ${clipHtml}
  `;
  logList.prepend(item);
}

clearLogBtn.addEventListener('click', () => {
  logList.innerHTML = '<div class="log-empty">No incidents recorded yet.<br>This log only exists in your browser tab and clears on refresh.</div>';
  incidentCount = 0;
  logCount.textContent = '0 events';
});

// ---- manual simulate button: synthesizes a fake fall in the trail + triggers alert ----
simulateBtn.addEventListener('click', () => {
  const now = performance.now();
  // inject a synthetic spike into history so the trail visibly shows it
  const baseY = 0.35;
  for (let i = 0; i < 12; i++) {
    hipYHistory.push({ t: now - 1200 + i * 100, y: baseY + (i / 12) * 0.45, angle: 20 + i * 6 });
  }
  hipYHistory.push({ t: now, y: 0.82, angle: 80 });
  drawTrail();
  triggerFallAlert();
});

// ============================================================
// Init
// ============================================================

startBtn.addEventListener('click', startCamera);

// initial empty trail render
drawTrail();
